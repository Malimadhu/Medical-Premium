#LM PROJECT
#DATE: 1ST MAY 2023
#=============================GROUP 5==================================


#H0: Premium price has no difference on different factors Vs 
# H1: Premium price has difference on different factors

a=read.csv("C:/Users/madhu/Downloads/archive/Medicalpremium.csv")
View(a)
#The dataset Contains Health Related Parameters Of The Customers.
library(pastecs)
library(corrplot)
library(tidyverse)
library(ggplot2)
dim(a)
t <- tibble(a)
t              #to get a tibble of data 
head(a)
#The Premium Price Is In INR(₹) Currency And Showcases Prices For A Whole Year.
#Diabetes:Whether The Person Has Abnormal BloodSugar Levels
#BloodPressureProblems : Whether The Person Has Abnormal Blood Pressure Levels
#AnyTransplants : Any Major Organ Transplants
#AnyChronicDiseases : Whether Customer Suffers From Chronic Ailments Like Asthama, etc.
#Height & Weight Of Customer
#KnownAllergies : Whether The Customer Has Any Known Allergies
#HistoryOfCancerInFamily : Whether Any Blood Relative Of The Customer Has Had Any Form Of Cancer
#NumberOfMajorSurgeries : The Number Of Major Surgeries That The Person Has Had
stat.desc(a)
summary(a)
colSums(is.na(a))    #gives sum of null values in each column
#EDA to see distribution of data
ggplot(data=a)+
  geom_point(mapping=aes(x=PremiumPrice,y=Age,color=NumberOfMajorSurgeries,fill='clarity'))
#ggplot(data=a)+
#  geom_bar(mapping=aes(x=PremiumPrice,color=Age,fill='clarity'))
ggplot(a)+
  geom_point(mapping=aes(x=NumberOfMajorSurgeries,y= PremiumPrice,color="cut"))+
  facet_wrap(~NumberOfMajorSurgeries)

#Histogram
hist(a$Age,breaks = "Sturges",freq = NULL,
     include.lowest = TRUE, right = TRUE, fuzz = 1e-7,
     density = NULL, angle = 45, col = "darkblue", border = NULL,
     main = paste ("Histogram of Premium Price "),
     axes = TRUE, plot = TRUE, labels = FALSE)     #Max people are from age limit 40-50


#Scatter plot to check randomness
mp=cbind(a$PremiumPrice,a$Age,a$Diabetes,a$BloodPressureProblems,a$AnyTransplants,a$AnyChronicDiseases,a$Height,a$Weight,a$KnownAllergies,a$HistoryOfCancerInFamily,a$NumberOfMajorSurgeries)
pairs(mp)
c <- cor(a)            #Correlation matrix
c
corr_plot=corrplot(c,method="circle")   #correlation plot
#SLRM   
m <- lm(a$PremiumPrice~a$Age)
d <- summary(m)
d     
par(mfrow=c(2,2))
plot(m)
abline(m)
#MLRM
#H0:beta1=beta2=..=0 Vs H1: Atleast 1 regressor is significant
m_1 <- lm(a$PremiumPrice~a$Age+a$BloodPressureProblems+a$AnyTransplants+a$AnyChronicDiseases+a$NumberOfMajorSurgeries+a$Weight)
d_1 <- summary(m_1)
d_1

m_2 <- lm(a$PremiumPrice~a$Age+a$AnyTransplants+a$AnyChronicDiseases+a$NumberOfMajorSurgeries+a$Weight)
d_2 <-summary(m_2)
d_2
par(mfrow=c(2,2))
plot(m_2)



#Box plot to detect outliers
boxplot(a$Age,ylab="Age of Customer")
boxplot(a$Weight,ylab="Weight of Customer")
boxplot(a$PremiumPrice,ylab="Premium Prices For A Whole Year")
boxplot(a$NumberOfMajorSurgeries,ylab="Number of major surgeries of Customer")
boxplot(a$Height,ylab="Height of Customer")


#Removing outliers
#find Q1, Q3, and interquartile range for values in column of Premium price
Q1 <- quantile(a$PremiumPrice, .25)
Q3 <- quantile(a$PremiumPrice, .75)
IQR_1 <- IQR(a$PremiumPrice)
#only keep rows in dataframe that have values within 1.5*IQR of Q1 and Q3
no_outliers_1 <- subset(a, a$PremiumPrice> (Q1 - 1.5*IQR_1) &  a$PremiumPrice< (Q3 + 1.5*IQR_1))
#view row and column count of new data frame
a_1 <- dim(no_outliers_1)
a_1
#find Q1, Q3, and interquartile range for values in column of Weight
Q1_2 <- quantile(a$Weight, .25)
Q3_2 <- quantile(a$Weight, .75)
IQR_2 <- IQR(a$Weight)
no_outliers_2 <- subset(a, a$Weight> (Q1_2 - 1.5*IQR_2) &  a$Weight< (Q3_2 + 1.5*IQR_2))
#view row and column count of new data frame
a_2 <- dim(no_outliers_2)
a_2
#find Q1, Q3, and interquartile range for values in column of Number of major surgeries of customer 
Q1_3 <- quantile(a$NumberOfMajorSurgeries, .25)
Q3_3 <- quantile(a$NumberOfMajorSurgeries, .75)
IQR_3 <- IQR(a$Weight)
no_outliers_3 <- subset(a, a$NumberOfMajorSurgeries> (Q1_3 - 1.5*IQR_3) &  a$NumberOfMajorSurgeries< (Q3_3 + 1.5*IQR_3))
#view row and column count of new data frame
a_3 <- dim(no_outliers_3)
a_3
#The new data frame has 980 rows and 11 columns, which tells us that 6 rows were removed because they had at least one outlier in column PremiumPrice.

#m_3 <- lm(a_1$PremiumPrice~a$Age+a$AnyTransplants+a$AnyChronicDiseases+a_3$NumberOfMajorSurgeries+a_2$Weight)
#d_3 <-summary(m_3)
#par(mfrow=c(2,2))
#plot(m_3)

#Checking for heteroscedasticity
#Bartlett test   H0: Var1=Var2=...=Vark   Vs H1: Atleast 1 of them differs
bartlett.test(a)
#Pvalue < 0.05 so we reject null hypothesis.Therefore the difference in variance is significant.
#Chisq(0.95,11)=4.575 > 143249 
#Interpretation:
#We see that residuals are non linear, heteroskedastic.

#log Transformation
log_y <- log10(a$PremiumPrice)
m_4 <- lm(log_y~a$Age+a$AnyTransplants+a$AnyChronicDiseases+a_3$NumberOfMajorSurgeries+a_2$Weight)
d_4 <-summary(m_4)
d_4
par(mfrow=c(2,2))
plot(m_4)

#sqrt Transformation
sqrt_y <- sqrt(a$PremiumPrice)
m_5 <- lm(sqrt_y~ a$Age+a$AnyTransplants+a$AnyChronicDiseases+a$NumberOfMajorSurgeries+a$Weight)
d_5 <-summary(m_5)
d_5
par(mfrow=c(2,2))
plot(m_5)



#Normal QQ plot: Not perfectly normal, outliers are present.
#Test for autocorrelation.
durbinWatsonTest(m_2)
#p value is greater than 0.05 so we accept H0. ie autocorrelation is absent.
#Normality test
ks.test(a,"punif",0.1)
#We reject H0.(F(x)=F0(x))

library(GGally)
ggpairs(a,
        columns = c("a$PremiumPrice", "a$Age", "a$AnyTransplants", "AnyChronicDiseases","Weight"),
        ggplot2::aes(colour = classification)
)


#Logistic
m_6 <- glm(a$Diabetes~a$Age+a$BloodPressureProblems+a$Weight+a$AnyTransplants,family="binomial")
summary(m_6)
par(mfrow=c(2,2))
plot(m_4)

